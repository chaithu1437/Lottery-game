"use strict";

const pickNumberBtn = document.getElementById("pickNumberBtn");
const result = document.getElementById("result");
const lotterySheetcontainer = document.getElementById("lotterysheetcontainer");
const tick = new Audio("tap.wav");
const completedSound = new Audio("completedSound.wav");
const gifts = [
  "Chocolate Hamper",
  "Coffee Gift Box",
  "Spa Essentials Kit",
  "Fruit Basket",
  "Gourmet Snacks Pack",
  "Tea Lover’s Hamper",
  "Organic Beauty Set",
  "Stationery Combo",
  "Fitness Kit",
  "Book Lover's Pack",
  "Skincare Essentials",
  "Tech Accessories Pack",
  "Mini Plant Pot Set",
  "Home Fragrance Box",
  "Scented Candle Hamper",
  "Dry Fruits Box",
  "Bath & Body Kit",
  "DIY Craft Kit",
  "Cookie & Brownie Basket",
  "Travel Essentials Pouch",
  "Festive Sweets Box",
  "Luxury Perfume Set",
  "Wooden Decor Gift",
  "Personalized Mug Set",
  "Eco-Friendly Hamper",
  "Party Essentials Box",
  "Jewelry & Trinket Set",
  "Gaming Accessories Pack",
  "Herbal Wellness Hamper",
  "Painting & Art Kit",
  "Baked Goodies Hamper",
  "Movie Night Pack",
  "Winter Care Basket",
  "Customized T-shirt Box",
  "Sweets & Savory Combo",
  "Handcrafted Items Set",
  "Kids’ Activity Hamper",
  "Couple’s Romantic Set",
  "Birthday Surprise Box",
  "Festival Celebration Pack",
  "Music Lover’s Kit",
  "Men's Grooming Set",
  "Women’s Care Hamper",
  "Zodiac Sign Goodies Box",
  "Graduation Gift Pack",
  "Makeup & Brushes Kit",
  "Leather Accessories Set",
  "Friendship Day Hamper",
  "Anniversary Gift Combo",
  "Surprise Mystery Box",
];

console.log(gifts);

pickNumberBtn.addEventListener("click", function () {
  for (let i = 1; i <= 50; i++) {
    document.getElementById(i).classList.remove("winningBox");
  }
  result.textContent = "Please wait...";
  // setTimeout(function () {
  //   let randomNum = Math.random() * 50;
  //   let drawnNumber = Math.floor(randomNum) + 1;
  //   const gift = gifts[drawnNumber - 1];
  //   result.textContent = `you have got ${drawnNumber}. and you won "${gift}".`;
  //   document.getElementById(drawnNumber).classList.add("winningBox");
  // }, 5000);

  let secondsCount = 0;
  const intervalId = setInterval(function () {
    tick.pause();
    tick.currentTime = 0;
    tick.play();
    secondsCount++;
    const randomBox = Math.floor(Math.random() * 50) + 1;
    console.log(randomBox);

    for (let i = 1; i <= 50; i++) {
      if (i == randomBox) {
        document.getElementById(i).classList.add("highletedBox");
      } else {
        document.getElementById(i).classList.remove("highletedBox");
      }
    }
    if (secondsCount === 5) {
      let randomNum = Math.random() * 50;
      let drawnNumber = Math.floor(randomNum) + 1;
      const gift = gifts[drawnNumber - 1];
      result.textContent = `you have got ${drawnNumber}. and you won "${gift}".`;
      document.getElementById(randomBox).classList.remove("highletedBox");
      document.getElementById(drawnNumber).classList.add("winningBox");
      completedSound.pause();
      completedSound.currentTime = 0;
      completedSound.play();

      clearInterval(intervalId);
    }
  }, 1000);
});

gifts.forEach(function (value, i) {
  const boxElement = `<div class="box" id="${i + 1}"> ${i + 1}.${value}</div>`;
  console.log(boxElement);
  lotterySheetcontainer.insertAdjacentHTML("beforeend", boxElement);
});
